cat > /opt/scripts/backup_full.sh << 'EOF'
#!/bin/bash

##############################################################################
# Script: backup_full.sh
# Descripción: Realiza backups de directorios con fecha ANSI (YYYYMMDD)
# Valida que origen y destino existan y que sus sistemas de archivos
# estén disponibles. Incluye opción de ayuda (-h y -help).
##############################################################################

FECHA=$(date +%Y%m%d)

# Función de ayuda
mostrar_ayuda() {
    cat << 'HELP'
Uso: backup_full.sh -o <origen> -d <destino> [-h | -help]

Opciones:
    -o <origen>     Directorio origen a respaldar (requerido)
    -d <destino>    Directorio destino donde guardar el backup (requerido)
    -h, -help       Mostrar esta ayuda

Ejemplos:
    backup_full.sh -o /var/log  -d /backupdir
    backup_full.sh -o /wwwdir   -d /backupdir
HELP
}

# Si el primer parámetro es -help, mostrar la ayuda y salir
if [ "$1" = "-help" ]; then
    mostrar_ayuda
    exit 0
fi

# Procesar argumentos cortos
while getopts "o:d:h" opt; do
    case "$opt" in
        o) ORIGEN="$OPTARG" ;;
        d) DESTINO="$OPTARG" ;;
        h) mostrar_ayuda; exit 0 ;;
        *) echo "Opción inválida"; mostrar_ayuda; exit 1 ;;
    esac
done

# Validar argumentos requeridos
if [ -z "$ORIGEN" ] || [ -z "$DESTINO" ]; then
    echo "Error: deben indicarse -o <origen> y -d <destino>"
    mostrar_ayuda
    exit 1
fi

# Validar que el directorio origen existe
if [ ! -d "$ORIGEN" ]; then
    echo "Error: el directorio origen '$ORIGEN' no existe"
    exit 1
fi

# Validar que el directorio destino existe
if [ ! -d "$DESTINO" ]; then
    echo "Error: el directorio destino '$DESTINO' no existe"
    exit 1
fi

# Validar que el sistema de archivos del origen está disponible
if ! df "$ORIGEN" > /dev/null 2>&1; then
    echo "Error: sistema de archivos de origen no disponible"
    exit 1
fi

# Validar que el sistema de archivos del destino está disponible
if ! df "$DESTINO" > /dev/null 2>&1; then
    echo "Error: sistema de archivos de destino no disponible"
    exit 1
fi

# Nombre base del directorio origen
DIR_NOMBRE=$(basename "$ORIGEN")

# Nombre del archivo de backup con fecha ANSI
ARCHIVO_BACKUP="${DIR_NOMBRE}_bkp_${FECHA}.tar.gz"

# Ruta completa del backup
RUTA_BACKUP="${DESTINO}/${ARCHIVO_BACKUP}"

# Realizar backup
echo "Iniciando backup de '$ORIGEN' en '$RUTA_BACKUP'..."
tar -czf "$RUTA_BACKUP" -C "$(dirname "$ORIGEN")" "$(basename "$ORIGEN")" 2>/dev/null

# Verificar resultado
if [ $? -eq 0 ]; then
    echo "Backup completado exitosamente: $RUTA_BACKUP"
    echo "Tamaño: $(du -h "$RUTA_BACKUP" | cut -f1)"
    exit 0
else
    echo "Error: fallo durante la creación del backup"
    exit 1
fi
EOF
